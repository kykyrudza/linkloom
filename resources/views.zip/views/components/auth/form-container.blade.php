<div
    class="min-w-[300px] min-h-[150px] bg-white bg-opacity-10 custom-blur border shadow-custom-combined border-white border-opacity-10 p-6 rounded-[30px] mx-1 md:mx-3 flex flex-col items-center justify-center {{ $attributes->get('class') }}"
    style="display: table;"
>
    {{ $slot }}
</div>
