<div class="mb-4 md:mb-6">
    <a href="{{ $url ?? '#' }}" class="text-white text-opacity-50 text-lg underline hover:text-white">{{ $slot }}</a>
</div>
