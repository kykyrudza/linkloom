<h2 class="text-white  text-center text-4xl md:text-5xl mb-10 md:mb-20">{{ $title }}</h2>
