<button type="submit" class="h-[50px] w-[140px] md:h-[64px] md:w-[210px] md:text-2xl p-2 rounded-full custom-blur shadow-custom-combined text-white hover:bg-green-500 hover:bg-opacity-50 text-lg">
    {{ $slot }}
</button>
