@extends('layouts.layout')

@section('title')
    Ups :(
@endsection

@section('content')
    <div class="flex text-white text-4xl h-screen items-center justify-center">
        <p>Ups, нам кажеться это не ваши настройки!</p>
    </div>
@endsection